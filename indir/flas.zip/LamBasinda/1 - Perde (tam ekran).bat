@echo off
rem Perdeyi tam ekran acar (Chrome, yoksa Edge, yoksa varsayilan tarayici).
set "U=https://olgunak.github.io/lam-basinda/canli/perde.html"
for %%P in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe") do (
  if exist %%P ( start "" %%P --new-window --start-fullscreen "%U%" & exit /b )
)
start "" "%U%"
